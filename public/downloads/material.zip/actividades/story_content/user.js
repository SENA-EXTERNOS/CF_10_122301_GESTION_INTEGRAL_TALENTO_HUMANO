function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5YAJWbFQ2pV":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

