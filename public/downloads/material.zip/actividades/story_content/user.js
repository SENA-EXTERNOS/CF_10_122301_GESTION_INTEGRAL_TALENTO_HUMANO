function ExecuteScript(strId)
{
  switch (strId)
  {
      case "60uNo9xgZTC":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

