function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5jukdQ6CsW4":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

